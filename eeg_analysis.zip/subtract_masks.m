function [masking_subtracted_data] = subtract_masks(cond_names,sub_inds, data, data_avg, is_resample, use_iv_b)
% subtract mask related activity from each trial separately

for ind = 1:length(cond_names)
    for sub = sub_inds
        num_trials = length(data.(cond_names{ind})(sub).EEG.trial);
        
        % select the compatible mask for each condition
        switch cond_names{ind}(1)
            case 'V'
                current_blank = data_avg.V_b(sub).EEG.avg;
            case 'I'
                if use_iv_b
                    current_blank = data_avg.IV_b(sub).EEG;
                else
                    cfg = [];
                    cfg.offset    = -(0.075*data.(cond_names{ind})(sub).EEG.fsample); % shift in 75 ms times the sampling rate
                    current_blank = ft_redefinetrial(cfg, data_avg.V_b(sub).EEG);
                    current_blank = current_blank.avg;
%                     current_blank = data_avg.IV_b(sub).EEG.avg;
                end
        end
%         cfg = [];
%         cfg.toilim    = [-0.5 1];
%         current_blank = ft_redefinetrial(cfg, current_blank);
%         current_data = ft_redefinetrial(cfg, data.(cond_names{ind})(sub).EEG);
        current_data = data.(cond_names{ind})(sub).EEG;

        if is_resample
            cfg = [];
            cfg.resamplefs = 200;
            current_blank = ft_resampledata(cfg, current_blank);
            current_data = ft_resampledata(cfg, current_data);
        end
        
        % subtract mask from each trial        
        trial_cell = cell(1, num_trials);
        for trial = 1:num_trials
            trial_cell{trial} = current_data.trial{trial} - current_blank; 
        end
        
        current_data.trial = trial_cell;
        masking_subtracted_data(sub).(cond_names{ind}) = current_data;
    end
end


end

